Thank you for downloading Mr Pwnage's Stick Online Cursors!

All sprites and ideas plus the game these cursors are based off of all belong to the Stick Online Team.
I have taken their sprites and fixed them up and completely rebuilt some (like the inferno sword cursor)
to make them easy-use-cursors. I hope you enjoy them!

-Mr Pwnage